

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

//import java.io.BufferedReader;
//import java.io.File;
//import java.io.FileReader;
import Business.LibCheck;
/**
 * Servlet implementation class UrlCheck
 */
@WebServlet("/UrlCheck")
public class UrlCheck extends HttpServlet {
	private static final long serialVersionUID = 1L;

    /**
     * Default constructor. 
     */
    public UrlCheck() {
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		String searchText = request.getParameter("searchtext");
		System.out.println("servlet started");
		System.out.println("servlet running");
		LibCheck l1 = new LibCheck();
		boolean valid;
		try {
			if(l1.isValidURL(searchText)) {
				response.sendRedirect(searchText);
			}
			else {
				response.sendRedirect("New2.jsp");
			}
			valid = l1.isValidURL(searchText);
			System.out.println(searchText);
			System.out.println(valid);
		}
		catch(IOException e) {
			System.out.println(e);
		}

		System.out.println("servlet ends");
		
	}

}
