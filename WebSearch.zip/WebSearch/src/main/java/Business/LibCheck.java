package Business;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;

public class LibCheck {
	
	public boolean isValidURL(String URL) throws IOException {
		String Library = new File( "." ).getCanonicalPath() + "/lib/";
		BufferedReader BR = new BufferedReader(new FileReader(Library + "Projects.txt"));
		String Projectline;
		
		//Reading the projects created by the web crawler
		while ((Projectline = BR.readLine()) != null) {
			Projectline = Projectline.replace("\n", "");
			BufferedReader URLSearch = new BufferedReader(new FileReader(Library + Projectline + "/crawled.txt"));
			String URLline;
			//Reading the current project's crawled.txt file to search for the URL provided
			while ((URLline = URLSearch.readLine()) != null) {
				URLline = URLline.replace("\n", "");
				if(URLline.equals(URL)) {
					BR.close();
					URLSearch.close();
					return true;
				}
			}
			URLSearch.close();
		}
		BR.close();
		return false;
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
